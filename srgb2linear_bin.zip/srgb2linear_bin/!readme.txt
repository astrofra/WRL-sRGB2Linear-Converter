= srgb2linear =
Author : astrofra@gmail.com

= How to use =
Converts the vertex colors of a WRL file from sRGB format to Linear format.
Put your files into the folder called 'wrl_files_here' and start 'srgb2linear.exe'.
The convert will create a copy of each .WRL file in the same folder.